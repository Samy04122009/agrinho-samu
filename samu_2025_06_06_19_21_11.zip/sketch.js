
function setup() {
  createCanvas(600, 400); // Cria uma tela de 600x400 pixels
}

function draw() {
  background(220); // Define o fundo da tela (cinza claro)

  // Desenhar elementos da simulação (planta, água, etc.)
  // (Aqui você adicionará o código para desenhar a planta, o sol, a chuva, etc.)

  // Adicionar interatividade (se desejar)
  // (Aqui você adicionará o código para responder a eventos do mouse ou teclado)
}
let alturaPlanta = 50; // Altura inicial da planta
const taxaCrescimento = 5; // Quanto a planta cresce a cada clique

function setup() {
  createCanvas(600, 400); // Cria uma tela de 600x400 pixels
  textAlign(CENTER); // Alinha o texto ao centro
  textSize(16); // Define o tamanho da fonte para os textos
}

function draw() {
  background(173, 216, 230); // Fundo azul claro (céu)

  // --- Desenhar o Sol ---
  fill(255, 255, 0); // Cor amarela para o sol
  noStroke(); // Sem contorno para o sol
  ellipse(width - 70, 70, 80, 80); // Desenha o sol no canto superior direito

  // --- Desenhar o Solo ---
  fill(139, 69, 19); // Cor marrom para o solo
  rect(0, height - 80, width, 80); // Desenha um retângulo para o solo na parte inferior

  // --- Desenhar a Planta ---
  // Caule
  fill(34, 139, 34); // Cor verde para o caule
  rect(width / 2 - 5, height - 80 - alturaPlanta, 10, alturaPlanta);

  // Folha (topo do caule)
  fill(50, 205, 50); // Cor verde mais clara para a folha
  ellipse(width / 2, height - 80 - alturaPlanta, 30, 30); // Uma folha simples no topo

  // --- Informação para o Usuário ---
  fill(0); // Cor preta para o texto
  text("Clique na tela para regar a planta!", width / 2, 30);
  text("Altura da planta: " + alturaPlanta.toFixed(0) + " pixels", width / 2, 60);

  // Mensagem sobre a importância da água
  fill(0, 100, 0); // Verde escuro para a mensagem
  if (alturaPlanta > 150) {
    text("Que bom! Sua planta está crescendo forte com água!", width / 2, height - 20);
  } else {
    text("A água é essencial para o crescimento das plantas!", width / 2, height - 20);
  }
}

function mousePressed() {
  // Aumenta a altura da planta quando o mouse é clicado
  alturaPlanta += taxaCrescimento;

  // Limita a altura máxima da planta para não sair da tela
  if (alturaPlanta > height - 100) {
    alturaPlanta = height - 100;
  }
}

